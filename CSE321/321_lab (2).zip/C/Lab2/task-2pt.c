#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
int a=1;
void *f1(void *ptr){
	char *message;
	message=(char*) ptr;
	for(int i=0;i<5;i++){
		printf("%s prints %d\n",message,a);
		a++;	
	}
}

int main(int argc, char* argv[]){

	pthread_t t1,t2,t3,t4,t5;
	
	char *m1="Thread 0";
	char *m2="Thread 1";	
	char *m3="Thread 2";
	char *m4="Thread 3";
	char *m5="Thread 4";
	
	pthread_create(&t1,NULL,f1,(void*)m1);
	pthread_join(t1,NULL);
	
	pthread_create(&t2,NULL,f1,(void*)m2);
	pthread_join(t2,NULL);
	
	pthread_create(&t3,NULL,f1,(void*)m3);
	pthread_join(t3,NULL);
	
	pthread_create(&t4,NULL,f1,(void*)m4);
	pthread_join(t4,NULL);
	
	pthread_create(&t5,NULL,f1,(void*)m5);
	pthread_join(t5,NULL);
	
	return 0;
}
