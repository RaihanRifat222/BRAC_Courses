#include<stdio.h>
void perfect(int x, int y){

    while(x<=y){
        int c=1;
        int sum=0;
    
        while(c<x){
            if(x%c==0){
                sum+=c;
            }
            c++;
        }

        if(sum==x) {
            printf("%d\n",x);
            printf("\n");
        }
        x++;
    }

}
int main(){
    int n1,n2;
    scanf("%d",&n1);
    printf("\n");
    scanf("%d",&n2);
    printf("\n");
    perfect(n1,n2);
    return 0;
}

