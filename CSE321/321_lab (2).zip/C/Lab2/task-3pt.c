#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<string.h>
int sum=0;
void *f1(void *ptr){
	char *message;
	message=(char*) ptr;
	sum=0;
	for(int i=0;i<strlen(message);i++){
		sum=sum+message[i];
	}
	int *d=&sum;
	return d;
}

int main(int argc, char* argv[]){

	pthread_t t1,t2,t3;
	int *iret1; 
	int *iret2; 
	int *iret3;
	
	char *m1=argv[1];
	char *m2=argv[2];	
	char *m3=argv[3];
	
	
	pthread_create(&t1,NULL,f1,(void*)m1);
	pthread_join(t1, (void*)&iret1);
	int a=*iret1;
	pthread_create(&t2,NULL,f1,(void*)m2);
	pthread_join(t2, (void*)&iret2);
	int b=*iret2;
	pthread_create(&t3,NULL,f1,(void*)m3);
	pthread_join(t3, (void*)&iret3);
	int c=*iret3;
	
	if(a==b){
		if(a==c){
			printf("Youreka\n");
		}
		else{
			printf("Miracle\n");
		}
	}
	else if(a==c){
		printf("Miracle\n");
	}
	else if(b==c){
		printf("Miracle\n");
	}
	else{
		printf("Hasta la vista\n");
	}
	
	
	return 0;
}
