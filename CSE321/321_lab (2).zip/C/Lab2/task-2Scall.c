#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(){
    int pid,pid2,status,status2;
    pid=fork();
    if(pid!=0){
        wait(&status);
        printf("I am parent\n");
    }
    else{
        pid2=fork();
        if(pid2!=0){
            wait(&status2);
            printf("I am child\n");
        }
        else{
            printf("I am grandchild\n");
        }
    }

    return 0;
}