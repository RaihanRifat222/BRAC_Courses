#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
int main(){
    int fd;
    char buff[80];
    fd=open("hello.txt",O_WRONLY | O_CREAT);
    while(1){
        scanf("%s",buff);
        if(strcmp(buff,"-1")!=0){
            break;
        }
        write(fd,buff,strlen(buff));
    }
    close(fd);
    return 0;
}