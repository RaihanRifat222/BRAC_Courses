#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int convert(char *ptr){
    int i,x;
    for(i=0,x=0;ptr[i];i++){
        x=x*10+(ptr[i]-48);
    }
    return x;
}

int main(int argc, char* argv[]){
    int pid,status;
    pid=fork();
    if(pid==0){
        execl("sort.c","sort.c",argc,argv,NULL);
        int a=argc;
        int arr[a-1];

        for(int i=1;i<a;i++){
            arr[i-1]=convert(argv[i]);
        }

        for (int j=0;j<a-2;j++){
            for (int i=0; i<a-1-j-1;i++) {
                if (arr[i]>arr[i+1]){
                    int temp=arr[i];
                    arr[i]=arr[i+1];
                    arr[i+1]=temp;
                }
            }
    
        }

        for(int i=a-2;i>=0;i--){
            printf("%d ",arr[i]);
        }
        printf("\n");
    }
    else{
        wait(&status);
        execl("oddeven.c","oddeven.c",argc,argv,NULL);
        int a=argc;
        int arr[a-1];

        for(int i=1;i<a;i++){
            arr[i-1]=convert(argv[i]);
        }
        for(int i=0;i<a-1;i++){
            if(arr[i]%2==1){
                printf("%d is Odd.\n",arr[i]);
            }
            else{
                printf("%d is Even.\n",arr[i]);
            }
        }
    }
    return 0;
}