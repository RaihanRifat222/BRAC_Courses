#include<stdio.h>
struct Breakfast{
    int quantity;
    int price;
};
int main(){

    struct Breakfast paratha;
    printf("Quantity Of Paratha: ");
    scanf("%d",&paratha.quantity);
    printf("\n");
    printf("Unit Price: ");
    scanf("%d",&paratha.price);
    printf("\n");

    struct Breakfast vegetable;
    printf("Quantity Of Vegetable: ");
    scanf("%d",&vegetable.quantity);
    printf("\n");
    printf("Unit Price: ");
    scanf("%d",&vegetable.price);
    printf("\n");

    struct Breakfast water;
    printf("Quantity Of Mineral Water: ");
    scanf("%d",&water.quantity);
    printf("\n");
    printf("Unit Price: ");
    scanf("%d",&water.price);
    printf("\n");

    int total=(paratha.price*paratha.quantity+vegetable.price*vegetable.quantity+water.price*water.quantity);
    int num;
    printf("Number of People: ");
    scanf("%d",&num);
    printf("\n");
    float final=total/num;
    printf("Individual people will pay: %.2f tk",final);
    return 0;
}