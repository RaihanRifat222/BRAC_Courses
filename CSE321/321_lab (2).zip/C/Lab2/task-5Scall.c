#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(){
    int pid,pid2,pid3,pid4,c,g1,g2,g3,system,p;
    pid=fork();
    if(pid==0){
        c=getpid();
        printf("2. Child process ID : %d\n",c);
        pid2=fork();
        if(pid2==0){
            g1=getpid();
            printf("3. Grand Child process ID : %d\n",g1);
        }
        else{
            pid3=fork();
            if(pid3==0){
                g2=getpid();
                printf("4. Grand Child process ID : %d\n",g2);
            }
            else{
                pid4=fork();
                if(pid4==0){
                    wait(&system);
                    g3=getpid();
                    printf("5. Grand Child process ID : %d\n",g3);
                }
            }
        }
    }
    else{
        p=getppid();
        printf("1. Parent process ID : %d\n",p);
    }

    return 0;
}
