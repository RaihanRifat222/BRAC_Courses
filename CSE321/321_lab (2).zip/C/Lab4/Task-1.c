#include<stdio.h>
int main(){

    int proc=0,n;
    printf("Number of Processes : ");
    scanf("%d",&n);
    int areT[n],buT[n],reT[n*2],eT,small;
    for(int i=0;i<n;i++){
        printf("AT of Process P%d : ",i+1);
        scanf("%d",&areT[i]);
        printf("BT of Process P%d : ",i+1);
        scanf("%d",&buT[i]);
        reT[i]=buT[i];
    }
    reT[n*2-1]=9999;
    printf("\nProcess  CT\tTA\tWT\n");
    for(int j=0;proc!=n;j++){
        small=n*2-1;
        for(int i=0;i<n;i++){
            if(areT[i]<=j && reT[i]<reT[small] && reT[i]>0){
                small=i;
            }
        }
        reT[small]--;
        if(reT[small]==0){
            proc++;
            eT=j+1;
            printf("\nP[%d]\t%d\t%d\t%d",small+1,eT,eT-areT[small],eT-buT[small]-areT[small]);
        }
    }
    return 0;
}