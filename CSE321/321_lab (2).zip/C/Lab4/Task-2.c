#include<stdio.h>
int main(){

    int c=0,n,it,tmq; 
    printf("Number of Processes : ");
    scanf("%d",&n);
    int areT[n*2],buT[n*2],reT[n*2];
    it=n;
    for(int i=0;i<n;i++){
        areT[i]=0;
        printf("Burst Time: ");
        scanf("%d",&buT[i]);
        reT[i]=buT[i];
    }
    printf("Time Quantum: ");
    scanf("%d",&tmq);
    printf("\nProcess \tCT \tTAT \tWT\n");
    for(int j=0,i=0;it!=0;){
        if(reT[i]<=tmq && reT[i]>0){
            j=j+reT[i];
            reT[i]=0;
            c=1;
        }
        else if(reT[i]>0){
            reT[i]=reT[i]-tmq;
            j=j+tmq;
        }
        if(reT[i]==0 && c==1){
            it--;
            printf("\nProcess[%d]\t%d \t%d \t%d\n",i+1,j,j-areT[i],j-areT[i]-buT[i]);
            c=0;
        }
        if(i==n-1){
            i=0;
        }
        else if(areT[i+1]<=j){
            i++;
        }
        else{
            i=0;
        }
    }
    return 0;
}