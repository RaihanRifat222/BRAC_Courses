#include<stdio.h>
int main(){

    int n=5,c=0,it;
    printf("Number of Processes : ");
    scanf("%d",&n);
    int areT[n],buT[n],reT[n*2],temp[n],tuT[n],prT[n],waT[n];
    for(int i=0;i<n;i++){
        printf("AT of Process P%d : ",i+1);
        scanf("%d",&areT[i]);
        printf("BT of Process P%d : ",i+1);
        scanf("%d",&buT[i]);
        temp[i]=buT[i];
        printf("PT of Process P%d : ",i+1);
        scanf("%d",&prT[i]);
    }
    prT[n*2-1]=9999;
    for(int j=0;c!=n;j++){
        it=n*2-1;
        for(int i=0;i<n;i++){
            if(prT[it]>prT[i] && areT[i]<=j && buT[i]>0){
                it=i;
            }
        }
        buT[it]=buT[it]-1;
        if(buT[it]==0){
            waT[it]=j+1-areT[it]-temp[it];
            tuT[it]=j+1-areT[it];
            c+=1;
        }
    }
    printf("\nProcess \tCT \tTAT \tWT\n");
    for(int i=0;i<n;i++){
        printf("\nProcess[%d]\t%d \t%d \t%d\n",i+1,areT[i]+tuT[i],waT[i],tuT[i]);
    }
    return 0;
}