#include <stdio.h>
#include <stdbool.h>

int main(){
    int alloc[5][4] = { { 0, 1, 0, 3 },
                        { 2, 0, 0, 0 },
                        { 3, 0, 2, 0 },
                        { 2, 1, 1, 5 },
                        { 0, 0, 2, 2 } };
    int max[5][4] = { { 6, 4, 3, 4 },
                        { 3, 2, 2, 1 },
                        { 9, 1, 2, 6 },
                        { 2, 2, 2, 8 }, 
                        { 4, 3, 3, 7 } };
    int avail[4] = { 3, 3, 2, 1 };
    int req[5][4];
    for(int i=0;i<5;i++){
        for(int j=0;j<4;j++){
            req[i][j]=max[i][j]-alloc[i][j];
        }
    }
    bool flag[5];
    for(int i=0;i<5;i++){
        flag[i]=false;
    }
    int check;
    for(int k=0;k<2;k++){
        for(int i=0;i<5;i++){
            check=0;
            for(int j=0;j<4;j++){
                if(req[i][j]<=avail[j]){
                    check++;
                }
                else{
                    break;
                }
            }
            if(check==4){
                flag[i]=true;
                while(check>=0){
                    avail[check]+=alloc[i][check];
                    check--;
                }
            }
        }
    }
    int lastCheck=0;
    for(int i=0;i<5;i++){
        if(flag[i]==false){
            lastCheck++;
            break;
        }
    }
    if(lastCheck==0){
        printf("Safe here\n");
    }
    else{
        printf("Deadlock Ahead\n");
    }
    
}