#include <stdio.h>
#include <stdbool.h>

int main(){
    int proc[6];
    for(int i=0;i<6;i++){
        proc[i]=0;
    }
    int alloc[6][4] = { { 0, 1, 0, 3 },
                        { 2, 0, 0, 3 },
                        { 3, 0, 2, 0 },
                        { 2, 1, 1, 5 },
                        { 0, 0, 2, 2 },
                        {1, 2 , 3, 1 } };
    int max[6][4] = { { 6, 4, 3, 4 }, 
                    { 3, 2, 2, 4 },
                    { 9, 1, 2, 6 },
                    { 2, 2, 2, 8 },
                    { 4, 3, 3, 7 },
                    { 6, 2 , 6, 5 } };
    int avail[4] = { 2, 2, 2, 1 };
    int req[6][4];
    for(int i=0;i<6;i++){
        for(int j=0;j<4;j++){
            req[i][j]=max[i][j]-alloc[i][j];
        }
    }
    bool flag[6];
    for(int i=0;i<6;i++){
        flag[i]=false;
    }
    int check;
    for(int k=0;k<2;k++){
        for(int i=0;i<6;i++){
            check=0;
            for(int j=0;j<4;j++){
                if(req[i][j]<=avail[j]){
                    check++;
                }
                else{
                    break;
                }
            }
            if(check==4){
                if(proc[i]!=1){
                    proc[i]=1;
                    printf("P%d->",i); 
                }
                flag[i]=true;
                while(check>=0){
                    avail[check]+=alloc[i][check];
                    check--;
                }
            }
        }
    }
    printf("\n");
    int lastCheck=0;
    for(int i=0;i<6;i++){
        if(flag[i]==false){
            lastCheck++;
            break;
        }
    }
    if(lastCheck==0){
        printf("Safe here\n");
    }
    else{
        printf("Deadlock Ahead\n");
    }
    
}