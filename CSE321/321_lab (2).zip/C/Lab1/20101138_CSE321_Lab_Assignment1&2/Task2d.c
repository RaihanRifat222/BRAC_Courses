#include<stdio.h>
#include<string.h>
int main(){
    char search[]="@sheba.xyz";
    char in[100];
    scanf("%s",in);
    char *ptr = strstr(in, search);
	if(ptr != NULL){
        printf("Email address is okay");
    }
    else{
        printf("Email address is outdated");
    }
    return 0;
}