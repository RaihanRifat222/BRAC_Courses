#include<stdio.h>
#include<string.h>
#include<stdbool.h>
int main(){
    char in[100];
    scanf("%s",in);
    char *ptr=&in[0];
    char *ptr2=&in[strlen(in)-1];
    bool x=false;
    for(int i=0;i<strlen(in);i++){
        if(*ptr==*ptr2){
            x=true;
        }
        else{
            x=false;
            break;
        }
        ptr++;
        ptr2--;
    }
    if(x==true){
        printf("Palindrome");
    }
    else{
        printf("Not Palindrome");
    }
    return 0;
}