#include<stdio.h>
#include<ctype.h>
#include<string.h>
int main(){
	char pass[100];
	int l=0,u=0,d=0,s=0;
	scanf("%s",pass);
    int i=0;
    int len=strlen(pass);
	while(i<len){
        if(islower(pass[i])!=0){
            l+=1;
        }
        else if(isupper(pass[i])!=0){
            u+=1;
        }
        else if(isdigit(pass[i])!=0){
            d+=1;
        }
        else{
            s+=1;          
        }
        i++;
	}
    if(l!=0 & u!=0 & d!=0 & s!=0){
        printf("Ok");
        return 0;
    }
    if(u==0){
		printf("Uppercase missing");
		if(l==0 || d==0 || s==0){
			printf(", ");
		}
	}
	if(l==0){
		printf("Lowercase missing");
		if(d==0 || s==0){
			printf(", ");
		}
	}
	if(d==0){
		printf("Digit missing");
		if(s==0){
			printf(", ");
		}
	}
	if(s==0){
		printf("Special missing");
	}
	return 0;
}