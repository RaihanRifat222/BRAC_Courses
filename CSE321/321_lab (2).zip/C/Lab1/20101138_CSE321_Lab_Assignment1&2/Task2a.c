#include <stdio.h>

void add(int num1, int num2);
void sub(int num1, int num2);
void mult(int num1, int num2);

int main(){
    int a,b;
    scanf("%d",&a);
    scanf("%d",&b);
    if(a>b){
        sub(a,b);
    }
    else if(b>a){
        add(a,b);
    }
    else{
        mult(a,b);
    }
    return 0;

}
void add(int num1, int num2){
    int sum=num1+num2;
    printf("%d",sum);

}
void sub(int num1, int num2){
    int dif=num1-num2;
    printf("%d",dif);

}
void mult(int num1, int num2){
    int prod=num1 * num2;
    printf("%d",prod);

}
