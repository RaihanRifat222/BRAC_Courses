#include<stdio.h>
int main(){

    printf("moja\n");
    return 0;
}